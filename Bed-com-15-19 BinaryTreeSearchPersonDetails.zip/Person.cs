// BED-C0M-15-19 DONNEX THOLERA KAMSONGA
public class Person
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public int Age { get; set; }
    public string UniqueID { get; set; }
}
